import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, ClassSession, UserRole } from '../types';
import Button from '../components/Button';
import { BookOpen, Video, Calendar, LogOut, Plus, X, Trash2, FileText, Award } from 'lucide-react';

interface DashboardProps {
  user: User;
  onLogout: () => void;
}

const MOCK_SESSIONS: ClassSession[] = [
  {
    id: '1',
    courseCode: 'COM 311',
    title: 'Operating Systems II',
    instructor: 'Dr. A. Okoro',
    startTime: '10:00 AM',
    isActive: true,
    topic: 'Process Scheduling Algorithms',
    credits: 3,
    description: 'Detailed study of process management, memory management hierarchy, file systems, and I/O subsystems.'
  },
  {
    id: '2',
    courseCode: 'COM 312',
    title: 'Database Design',
    instructor: 'Mrs. P. Eke',
    startTime: '12:00 PM',
    isActive: false,
    topic: 'Normalization Forms',
    credits: 3,
    description: 'Introduction to relational database concepts, SQL, and database normalization techniques.'
  },
  {
    id: '3',
    courseCode: 'GNS 301',
    title: 'Use of English III',
    instructor: 'Mr. J. Smith',
    startTime: '02:00 PM',
    isActive: false,
    topic: 'Technical Report Writing',
    credits: 2,
    description: 'Advanced communication skills focusing on technical report writing and presentation methods.'
  }
];

const Dashboard: React.FC<DashboardProps> = ({ user, onLogout }) => {
  const navigate = useNavigate();
  const [sessions, setSessions] = useState<ClassSession[]>(MOCK_SESSIONS);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    courseCode: '',
    title: '',
    topic: '',
    startTime: '',
    description: '',
    credits: ''
  });

  const handleJoinClass = (sessionId: string) => {
    navigate(`/classroom/${sessionId}`);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCreateClass = (e: React.FormEvent) => {
    e.preventDefault();
    const newSession: ClassSession = {
      id: Date.now().toString(),
      courseCode: formData.courseCode,
      title: formData.title,
      instructor: user.name,
      startTime: formData.startTime || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isActive: true, // Automatically active for demo
      topic: formData.topic,
      description: formData.description,
      credits: Number(formData.credits) || 0
    };
    
    setSessions(prev => [newSession, ...prev]);
    setIsModalOpen(false);
    setFormData({ courseCode: '', title: '', topic: '', startTime: '', description: '', credits: '' });
  };

  const handleDeleteClass = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this course session?')) {
      setSessions(prev => prev.filter(session => session.id !== id));
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Navbar */}
      <header className="bg-blue-900 text-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-white p-1 rounded-full">
              <BookOpen className="h-6 w-6 text-blue-900" />
            </div>
            <div>
              <h1 className="text-lg font-bold leading-tight">Captain Elechi Amadi Polytechnic</h1>
              <p className="text-xs text-blue-200">Computer Science Dept. Virtual Classroom</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium">{user.name}</p>
              <p className="text-xs text-blue-300">{user.role} • {user.email}</p>
            </div>
            <Button variant="secondary" onClick={onLogout} icon={<LogOut size={16} />}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        <div className="mb-8 flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Welcome back, {user.name.split(' ')[0]}</h2>
            <p className="text-gray-600 mt-1">
              {user.role === UserRole.LECTURER 
                ? "Manage your courses and scheduled lectures below." 
                : "Here are your scheduled lectures for today."}
            </p>
          </div>
          
          {user.role === UserRole.LECTURER && (
            <Button onClick={() => setIsModalOpen(true)} icon={<Plus size={18} />}>
              Create Course / Schedule Class
            </Button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sessions.map((session) => (
            <div key={session.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow flex flex-col">
              <div className={`h-2 w-full ${session.isActive ? 'bg-green-500' : 'bg-gray-300'}`} />
              <div className="p-6 flex-1 flex flex-col">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center space-x-2">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      {session.courseCode}
                    </span>
                    {session.credits && (
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-gray-100 text-gray-600 border border-gray-200" title="Course Credits">
                        <Award size={10} className="mr-1"/> {session.credits} Units
                      </span>
                    )}
                  </div>
                  {session.isActive ? (
                    <span className="flex h-3 w-3 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                    </span>
                  ) : (
                    user.role === UserRole.LECTURER && (
                      <button 
                        onClick={(e) => handleDeleteClass(session.id, e)}
                        className="text-gray-400 hover:text-red-500 transition-colors p-1"
                        title="Delete Course"
                      >
                        <Trash2 size={16} />
                      </button>
                    )
                  )}
                </div>
                
                <h3 className="text-lg font-bold text-gray-900 mb-1">{session.title}</h3>
                
                {session.description && (
                  <p className="text-xs text-gray-500 mb-3 line-clamp-2" title={session.description}>
                    {session.description}
                  </p>
                )}

                <div className="flex items-center text-sm text-gray-700 mb-1 font-medium">
                  <FileText size={14} className="mr-2 text-gray-400" />
                  <span className="truncate">Topic: {session.topic}</span>
                </div>
                
                <div className="flex items-center text-sm text-gray-500 mb-6 mt-auto">
                  <Calendar size={14} className="mr-2" />
                  <span>{session.startTime}</span>
                  <span className="mx-2">•</span>
                  <span className="truncate">{session.instructor}</span>
                </div>

                <Button 
                  onClick={() => handleJoinClass(session.id)}
                  disabled={!session.isActive && user.role === UserRole.STUDENT}
                  className="w-full"
                  icon={session.isActive ? <Video size={18} /> : undefined}
                >
                  {session.isActive ? 'Join Live Class' : 'Scheduled'}
                </Button>
              </div>
            </div>
          ))}
          
          {sessions.length === 0 && (
            <div className="col-span-full text-center py-12 text-gray-500 bg-white rounded-xl border border-dashed border-gray-300">
              <p>No courses or classes scheduled currently.</p>
              {user.role === UserRole.LECTURER && (
                <p className="text-sm mt-2 text-blue-600 cursor-pointer" onClick={() => setIsModalOpen(true)}>Create one now</p>
              )}
            </div>
          )}
        </div>
      </main>

      {/* Schedule Class Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm transition-opacity">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-lg overflow-hidden animate-fade-in-up">
            <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-blue-50">
              <h3 className="font-bold text-lg text-blue-900">Create Course & Schedule Class</h3>
              <button 
                onClick={() => setIsModalOpen(false)} 
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            
            <form onSubmit={handleCreateClass} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Course Code</label>
                  <input 
                    required
                    name="courseCode"
                    value={formData.courseCode}
                    onChange={handleInputChange}
                    placeholder="e.g. COM 401"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm transition-shadow"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Credit Units</label>
                  <input 
                    required
                    type="number"
                    min="1"
                    max="6"
                    name="credits"
                    value={formData.credits}
                    onChange={handleInputChange}
                    placeholder="e.g. 3"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm transition-shadow"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Course Title</label>
                <input 
                  required
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  placeholder="e.g. Artificial Intelligence"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm transition-shadow"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Course Description</label>
                <textarea 
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  rows={2}
                  placeholder="Brief summary of the course content..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm transition-shadow resize-none"
                />
              </div>

              <div className="border-t border-gray-100 pt-3 mt-1">
                <p className="text-xs text-blue-600 font-medium mb-3">Session Schedule</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Lecture Topic</label>
                    <input 
                      required
                      name="topic"
                      value={formData.topic}
                      onChange={handleInputChange}
                      placeholder="e.g. Neural Networks Intro"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm transition-shadow"
                    />
                  </div>
                   <div>
                    <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Start Time</label>
                    <input 
                      required
                      name="startTime"
                      type="time"
                      value={formData.startTime}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm transition-shadow"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-4 flex space-x-3">
                <Button type="button" variant="secondary" onClick={() => setIsModalOpen(false)} className="flex-1">
                  Cancel
                </Button>
                <Button type="submit" className="flex-1">
                  Create & Schedule
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
