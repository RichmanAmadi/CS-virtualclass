import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Message, User, ClassSession, UserRole } from '../types';
import { askTeachingAssistant, summarizeClassChat } from '../services/geminiService';
import Button from '../components/Button';
import { 
  Mic, MicOff, Video as VideoIcon, VideoOff, 
  MonitorUp, MessageSquare, X, Send, Download, 
  Disc, Users, Bot, Sparkles, XCircle
} from 'lucide-react';

interface ClassroomProps {
  user: User;
}

const Classroom: React.FC<ClassroomProps> = ({ user }) => {
  const { sessionId } = useParams();
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  // State
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [showChat, setShowChat] = useState(true);
  const [isAiProcessing, setIsAiProcessing] = useState(false);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [chatSummary, setChatSummary] = useState<string | null>(null);

  // Mock Session Data (In a real app, fetch this)
  const session: ClassSession = {
    id: sessionId || '1',
    courseCode: 'COM 311',
    title: 'Operating Systems II',
    instructor: 'Dr. A. Okoro',
    startTime: '10:00 AM',
    isActive: true,
    topic: 'Process Scheduling Algorithms'
  };

  // Initialize Media Stream (Webcam/Mic)
  useEffect(() => {
    const initStream = async () => {
      try {
        const userStream = await navigator.mediaDevices.getUserMedia({ 
          video: true, 
          audio: true 
        });
        setStream(userStream);
        if (videoRef.current) {
          videoRef.current.srcObject = userStream;
        }
      } catch (err) {
        console.error("Error accessing media devices:", err);
        alert("Camera/Microphone permissions are required for the classroom.");
      }
    };

    initStream();

    return () => {
      // Cleanup stream on unmount
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Only run on mount

  // Recording Logic
  const toggleRecording = useCallback(() => {
    if (isRecording) {
      mediaRecorderRef.current?.stop();
      setIsRecording(false);
    } else {
      if (!stream) return;
      
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Lecture-${session.courseCode}-${new Date().toISOString().slice(0, 10)}.webm`;
        a.click();
        window.URL.revokeObjectURL(url);
      };

      recorder.start();
      setIsRecording(true);
    }
  }, [isRecording, stream, session.courseCode]);

  // Chat Logic
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      senderId: user.id,
      senderName: user.name,
      content: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newMessage]);
    const currentQuestion = inputMessage;
    setInputMessage('');

    // Check for AI triggering (Mock: if user asks specifically or toggles feature)
    // For this demo, let's add a dedicated "Ask AI" button in the input area instead of auto-triggering
  };

  const handleAskAI = async () => {
    if (!inputMessage.trim()) return;
    
    // Add user message first
    const userMsg: Message = {
      id: Date.now().toString(),
      senderId: user.id,
      senderName: user.name,
      content: inputMessage,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMsg]);
    setInputMessage('');
    
    setIsAiProcessing(true);

    // Call Gemini
    const aiResponse = await askTeachingAssistant(userMsg.content, `${session.courseCode}: ${session.topic}`);
    
    const aiMsg: Message = {
      id: (Date.now() + 1).toString(),
      senderId: 'ai-tutor',
      senderName: 'AI Tutor',
      content: aiResponse,
      timestamp: new Date(),
      isAi: true
    };

    setMessages(prev => [...prev, aiMsg]);
    setIsAiProcessing(false);
  };

  const handleSummarize = async () => {
    if (messages.length === 0) return;
    setIsSummarizing(true);
    
    const history = messages.map(m => `${m.senderName}: ${m.content}`).join('\n');
    const summary = await summarizeClassChat(history, `${session.courseCode}: ${session.title}`);
    
    setChatSummary(summary);
    setIsSummarizing(false);
  };

  // Toggle Media
  const toggleMute = () => {
    if (stream) {
      stream.getAudioTracks().forEach(track => track.enabled = !isMuted);
      setIsMuted(!isMuted);
    }
  };

  const toggleVideo = () => {
    if (stream) {
      stream.getVideoTracks().forEach(track => track.enabled = !isVideoOff);
      setIsVideoOff(!isVideoOff);
    }
  };

  return (
    <div className="h-screen flex flex-col bg-gray-900 text-white overflow-hidden">
      {/* Header */}
      <header className="h-14 bg-gray-800 border-b border-gray-700 flex items-center justify-between px-4 shrink-0">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" className="text-gray-300 hover:text-white" onClick={() => navigate('/dashboard')}>
             &larr; Exit
          </Button>
          <div className="h-6 w-px bg-gray-600 mx-2"></div>
          <div>
            <h1 className="font-bold text-sm md:text-base">{session.courseCode}: {session.title}</h1>
            <p className="text-xs text-gray-400">{session.topic} • Dr. A. Okoro</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
           <div className={`flex items-center space-x-1 px-2 py-1 rounded text-xs ${isRecording ? 'bg-red-500/20 text-red-400' : 'text-gray-400'}`}>
              <div className={`w-2 h-2 rounded-full ${isRecording ? 'bg-red-500 animate-pulse' : 'bg-gray-500'}`}></div>
              <span>{isRecording ? 'REC' : 'Ready'}</span>
           </div>
        </div>
      </header>

      {/* Main Layout */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Video Stage (Left/Center) */}
        <div className="flex-1 flex flex-col relative bg-black">
          <div className="flex-1 flex items-center justify-center p-4">
            <div className="relative w-full max-w-5xl aspect-video bg-gray-800 rounded-lg overflow-hidden shadow-2xl border border-gray-700">
               <video 
                  ref={videoRef}
                  autoPlay 
                  playsInline 
                  muted 
                  className={`w-full h-full object-cover ${isVideoOff ? 'hidden' : 'block'}`}
               />
               {isVideoOff && (
                 <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-gray-700 p-8 rounded-full">
                       <span className="text-4xl font-bold text-gray-400">{user.name.charAt(0)}</span>
                    </div>
                 </div>
               )}
               
               {/* Overlay Info */}
               <div className="absolute bottom-4 left-4 bg-black/60 px-3 py-1 rounded-md text-sm font-medium backdrop-blur-sm">
                 {user.name} (You)
               </div>
            </div>
          </div>

          {/* Controls Bar */}
          <div className="h-20 bg-gray-800 border-t border-gray-700 flex items-center justify-center space-x-4 shrink-0">
             <button 
               onClick={toggleMute}
               className={`p-4 rounded-full transition-all ${isMuted ? 'bg-red-500 hover:bg-red-600' : 'bg-gray-700 hover:bg-gray-600'}`}
             >
               {isMuted ? <MicOff size={24} /> : <Mic size={24} />}
             </button>
             
             <button 
               onClick={toggleVideo}
               className={`p-4 rounded-full transition-all ${isVideoOff ? 'bg-red-500 hover:bg-red-600' : 'bg-gray-700 hover:bg-gray-600'}`}
             >
               {isVideoOff ? <VideoOff size={24} /> : <VideoIcon size={24} />}
             </button>

             {/* Screen Share (Mock) */}
             <button className="p-4 rounded-full bg-gray-700 hover:bg-gray-600 text-gray-200">
               <MonitorUp size={24} />
             </button>

             {/* Record Button */}
             <button 
               onClick={toggleRecording}
               className={`p-4 rounded-full transition-all flex items-center justify-center ${isRecording ? 'bg-red-500 hover:bg-red-600 text-white shadow-[0_0_15px_rgba(239,68,68,0.5)]' : 'bg-gray-700 hover:bg-gray-600 text-gray-200'}`}
               title={isRecording ? "Stop Recording" : "Record Lecture"}
             >
               {isRecording ? <Disc size={24} className="animate-spin" /> : <Download size={24} />}
             </button>

             <div className="w-px h-8 bg-gray-600 mx-2"></div>

             <button 
               onClick={() => setShowChat(!showChat)}
               className={`p-4 rounded-full transition-all ${showChat ? 'bg-blue-600 hover:bg-blue-700 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-200'}`}
             >
               <MessageSquare size={24} />
             </button>
          </div>
        </div>

        {/* Chat Sidebar (Right) */}
        {showChat && (
          <div className="w-80 md:w-96 bg-gray-50 border-l border-gray-200 flex flex-col shrink-0 text-gray-800 transition-all duration-300 absolute right-0 top-0 bottom-0 z-10 md:relative">
             <div className="p-4 bg-white border-b border-gray-200 flex justify-between items-center shadow-sm">
                <div className="flex items-center space-x-2">
                   <Users size={18} className="text-gray-500" />
                   <h3 className="font-semibold">Live Chat</h3>
                </div>
                <button onClick={() => setShowChat(false)} className="md:hidden p-1 hover:bg-gray-100 rounded">
                  <X size={20} />
                </button>
             </div>

             {/* Messages Area */}
             <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50 scrollbar-hide">
               {/* Welcome Message */}
               <div className="flex flex-col space-y-1">
                 <div className="bg-blue-100 text-blue-800 p-3 rounded-lg text-sm self-start max-w-[90%]">
                   Welcome to <strong>{session.title}</strong>. Please feel free to ask questions. You can also ask the AI Tutor for help!
                 </div>
               </div>

               {/* AI Chat Summary */}
               {chatSummary && (
                 <div className="bg-gradient-to-r from-purple-50 to-white border border-purple-200 p-4 rounded-xl shadow-sm relative animate-fade-in-up">
                   <div className="flex items-center justify-between mb-2">
                     <h4 className="text-xs font-bold text-purple-700 uppercase flex items-center">
                       <Sparkles size={12} className="mr-1.5" /> Discussion Summary
                     </h4>
                     <button
                       onClick={() => setChatSummary(null)}
                       className="text-purple-300 hover:text-purple-600 transition-colors"
                     >
                       <XCircle size={14} />
                     </button>
                   </div>
                   <div className="text-xs text-gray-700 whitespace-pre-line leading-relaxed">
                     {chatSummary}
                   </div>
                 </div>
               )}

               {messages.map((msg) => (
                 <div key={msg.id} className={`flex flex-col ${msg.senderId === user.id ? 'items-end' : 'items-start'}`}>
                    <div className="flex items-center space-x-2 mb-1">
                       {msg.isAi && <Bot size={14} className="text-purple-600" />}
                       <span className="text-xs font-semibold text-gray-500">{msg.senderName}</span>
                       <span className="text-[10px] text-gray-400">{msg.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                    </div>
                    <div className={`p-3 rounded-lg text-sm max-w-[90%] shadow-sm ${
                      msg.isAi 
                        ? 'bg-purple-100 text-purple-900 border border-purple-200' 
                        : msg.senderId === user.id 
                          ? 'bg-blue-600 text-white rounded-tr-none' 
                          : 'bg-white text-gray-800 border border-gray-200 rounded-tl-none'
                    }`}>
                       {msg.content}
                    </div>
                 </div>
               ))}
               {isAiProcessing && (
                 <div className="flex items-center space-x-2 text-xs text-purple-600 animate-pulse p-2">
                   <Bot size={14} />
                   <span>AI is thinking...</span>
                 </div>
               )}
               {isSummarizing && (
                 <div className="flex items-center space-x-2 text-xs text-purple-600 animate-pulse p-2">
                   <Sparkles size={14} />
                   <span>Generating summary...</span>
                 </div>
               )}
             </div>

             {/* Input Area */}
             <div className="p-4 bg-white border-t border-gray-200">
               <form className="relative">
                 <input
                    type="text"
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    placeholder="Type a question..."
                    className="w-full pl-4 pr-28 py-3 bg-gray-100 border-none rounded-lg focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-sm"
                 />
                 <div className="absolute right-2 top-1.5 flex items-center space-x-1">
                   <button 
                     type="button"
                     onClick={handleSummarize}
                     disabled={messages.length === 0 || isSummarizing}
                     className="p-1.5 text-yellow-600 hover:bg-yellow-100 rounded-md transition-colors disabled:opacity-50"
                     title="Summarize Chat"
                   >
                     <Sparkles size={18} />
                   </button>
                   <button 
                     type="button"
                     onClick={handleAskAI}
                     disabled={!inputMessage.trim() || isAiProcessing}
                     className="p-1.5 text-purple-600 hover:bg-purple-100 rounded-md transition-colors disabled:opacity-50"
                     title="Ask AI Tutor"
                   >
                     <Bot size={18} />
                   </button>
                   <button 
                     type="submit"
                     onClick={handleSendMessage}
                     disabled={!inputMessage.trim()}
                     className="p-1.5 text-blue-600 hover:bg-blue-100 rounded-md transition-colors disabled:opacity-50"
                     title="Send to Class"
                   >
                     <Send size={18} />
                   </button>
                 </div>
               </form>
               <div className="mt-2 text-[10px] text-center text-gray-400">
                  Captain Elechi Amadi Polytechnic • Virtual Classroom
               </div>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Classroom;