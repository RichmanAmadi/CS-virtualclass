import React, { useState } from 'react';
import { User, UserRole } from '../types';
import Button from '../components/Button';
import { GraduationCap, Lock, Mail, User as UserIcon } from 'lucide-react';

interface AuthProps {
  onLogin: (user: User) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [role, setRole] = useState<UserRole>(UserRole.STUDENT);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Mock Authentication Logic
    setTimeout(() => {
      const mockUser: User = {
        id: Date.now().toString(),
        name: name || (email.split('@')[0]),
        email: email,
        // If signing up, use selected role. If logging in, use email heuristic for demo.
        role: !isLogin ? role : (email.toLowerCase().includes('lecturer') ? UserRole.LECTURER : UserRole.STUDENT)
      };
      
      setIsLoading(false);
      onLogin(mockUser);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-slate-900 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row">
        
        {/* Form Section */}
        <div className="w-full p-8">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-900 mb-4">
              <GraduationCap size={24} />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Captain Elechi Amadi Polytechnic</h1>
            <p className="text-sm text-gray-500 mt-2">Computer Science Department Portal</p>
          </div>

          <div className="flex justify-center space-x-4 mb-6">
            <button 
              onClick={() => setIsLogin(true)}
              className={`pb-2 text-sm font-medium border-b-2 transition-colors ${isLogin ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500'}`}
            >
              Sign In
            </button>
            <button 
              onClick={() => setIsLogin(false)}
              className={`pb-2 text-sm font-medium border-b-2 transition-colors ${!isLogin ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500'}`}
            >
              Sign Up
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            
            {!isLogin && (
              <div className="grid grid-cols-2 gap-2 bg-gray-100 p-1 rounded-lg mb-2">
                <button
                  type="button"
                  onClick={() => setRole(UserRole.STUDENT)}
                  className={`py-2 text-sm font-medium rounded-md transition-all ${
                    role === UserRole.STUDENT
                      ? 'bg-white text-blue-700 shadow-sm ring-1 ring-black/5'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  Student
                </button>
                <button
                  type="button"
                  onClick={() => setRole(UserRole.LECTURER)}
                  className={`py-2 text-sm font-medium rounded-md transition-all ${
                    role === UserRole.LECTURER
                      ? 'bg-white text-blue-700 shadow-sm ring-1 ring-black/5'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  Staff / Lecturer
                </button>
              </div>
            )}

            {!isLogin && (
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <UserIcon size={18} className="text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Full Name"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-sm"
                />
              </div>
            )}

            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Mail size={18} className="text-gray-400" />
              </div>
              <input
                type="email"
                placeholder={isLogin ? "Student/Staff Email" : "Email Address"}
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-sm"
              />
            </div>

            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Lock size={18} className="text-gray-400" />
              </div>
              <input
                type="password"
                placeholder="Password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-sm"
              />
            </div>

            <Button type="submit" className="w-full mt-6" isLoading={isLoading}>
              {isLogin ? 'Access Portal' : 'Create Account'}
            </Button>
          </form>
          
          <div className="mt-6 text-center">
            <p className="text-xs text-gray-400">
              {isLogin 
                ? "For demo: use 'lecturer' in email for staff access." 
                : "Select your role to create an appropriate account type."}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Auth;