import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../components/Button';
import { GraduationCap, Video, Bot, BookOpen, Users, PlayCircle, ArrowRight, ShieldCheck } from 'lucide-react';

const Welcome: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-white flex flex-col font-sans text-gray-900">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2 cursor-pointer" onClick={() => navigate('/')}>
               <div className="bg-blue-900 text-white p-1.5 rounded-lg shadow-sm">
                 <GraduationCap size={24} />
               </div>
               <div>
                 <h1 className="text-lg font-bold text-blue-900 leading-none">PolyVirtual</h1>
                 <p className="text-[10px] text-gray-500 font-medium tracking-wider uppercase">CS Dept • CEAP</p>
               </div>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-sm font-medium text-gray-600 hover:text-blue-700 transition-colors">Features</a>
              <a href="#about" className="text-sm font-medium text-gray-600 hover:text-blue-700 transition-colors">About</a>
              <div className="h-4 w-px bg-gray-300"></div>
              <Button variant="ghost" onClick={() => navigate('/auth')} className="text-gray-600">Sign In</Button>
              <Button onClick={() => navigate('/auth')}>Get Started</Button>
            </div>

            <div className="md:hidden">
              <Button size="sm" onClick={() => navigate('/auth')}>Login</Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="flex-1 relative overflow-hidden">
        {/* Background blobs */}
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-blue-50 blur-3xl opacity-50 z-0"></div>
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 rounded-full bg-purple-50 blur-3xl opacity-50 z-0"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 relative z-10">
          <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
            <div className="flex-1 text-center lg:text-left space-y-8">
              <div>
                <span className="inline-flex items-center px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-semibold uppercase tracking-wider mb-4 border border-blue-200">
                  Captain Elechi Amadi Polytechnic
                </span>
                <h1 className="text-4xl md:text-6xl font-extrabold text-gray-900 leading-tight tracking-tight">
                  Virtual Learning for <br className="hidden md:block"/>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-700 to-indigo-600">
                    Computer Science
                  </span>
                </h1>
              </div>
              
              <p className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
                Experience the next generation of academic collaboration. Attend real-time lectures, access AI-powered teaching assistants, and manage your coursework seamlessly.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                 <Button className="h-12 px-8 text-base shadow-xl shadow-blue-200 hover:shadow-blue-300 transition-all transform hover:-translate-y-1" onClick={() => navigate('/auth')}>
                   Join Classroom <ArrowRight size={18} className="ml-2" />
                 </Button>
                 <Button variant="secondary" className="h-12 px-8 text-base bg-white" onClick={() => navigate('/auth')}>
                   Faculty Portal
                 </Button>
              </div>

              <div className="pt-4 flex items-center justify-center lg:justify-start space-x-8 text-gray-400 text-sm">
                 <div className="flex items-center"><ShieldCheck size={16} className="mr-2 text-green-500"/> Secure Access</div>
                 <div className="flex items-center"><Users size={16} className="mr-2 text-blue-500"/> Live Interaction</div>
              </div>
            </div>
            
            <div className="flex-1 w-full max-w-lg lg:max-w-none">
               <div className="relative group perspective-1000">
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl transform rotate-3 group-hover:rotate-2 transition-transform duration-500 blur opacity-25"></div>
                  <div className="relative bg-white rounded-2xl p-2 shadow-2xl border border-gray-100 transform group-hover:-translate-y-2 transition-all duration-500">
                      <div className="bg-slate-900 rounded-xl overflow-hidden aspect-video relative">
                          {/* Mock UI Interface */}
                          <div className="absolute top-4 left-4 right-4 flex justify-between items-center z-10">
                             <div className="bg-black/40 backdrop-blur-sm px-3 py-1 rounded-full text-white text-xs font-medium flex items-center">
                                <div className="w-2 h-2 bg-red-500 rounded-full mr-2 animate-pulse"></div> Live Lecture
                             </div>
                             <div className="flex -space-x-2">
                                {[1,2,3].map(i => (
                                  <div key={i} className={`w-8 h-8 rounded-full border-2 border-slate-900 bg-gray-${300+i*100} flex items-center justify-center text-xs font-bold text-gray-600 bg-gray-200`}>
                                    S{i}
                                  </div>
                                ))}
                             </div>
                          </div>
                          
                          {/* Central Content */}
                          <div className="absolute inset-0 flex items-center justify-center">
                             <div className="text-center">
                                <div className="w-16 h-16 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center mx-auto mb-4 border border-white/20">
                                   <PlayCircle size={32} className="text-white" />
                                </div>
                                <p className="text-white/80 font-mono text-sm">COM 311: Operating Systems II</p>
                             </div>
                          </div>

                          {/* AI Assistant Pop */}
                          <div className="absolute bottom-4 right-4 bg-white p-3 rounded-lg shadow-lg max-w-[200px] animate-fade-in-up">
                             <div className="flex items-center space-x-2 mb-2">
                                <div className="bg-purple-100 p-1 rounded">
                                   <Bot size={14} className="text-purple-600"/>
                                </div>
                                <span className="text-xs font-bold text-gray-800">AI Tutor</span>
                             </div>
                             <div className="h-1.5 w-full bg-gray-100 rounded-full mb-1">
                                <div className="h-full w-2/3 bg-purple-400 rounded-full"></div>
                             </div>
                             <div className="h-1.5 w-3/4 bg-gray-100 rounded-full">
                                <div className="h-full w-1/2 bg-purple-300 rounded-full"></div>
                             </div>
                          </div>
                      </div>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="bg-gray-50 py-20 px-4 sm:px-6 lg:px-8 border-t border-gray-200">
         <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
               <h2 className="text-3xl font-bold text-gray-900">Why choose PolyVirtual?</h2>
               <p className="text-gray-500 mt-4 max-w-2xl mx-auto">Designed specifically for the academic needs of CS students and staff at Captain Elechi Amadi Polytechnic.</p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
               <FeatureCard 
                  icon={<Video className="text-blue-600" size={32} />}
                  title="HD Live Classes"
                  description="High-quality video streaming for lectures with integrated screen sharing, whiteboards, and presentation tools."
               />
               <FeatureCard 
                  icon={<Bot className="text-purple-600" size={32} />}
                  title="AI Teaching Assistant"
                  description="Leverage Gemini AI to answer questions in real-time, explain complex code, and provide study summaries."
               />
               <FeatureCard 
                  icon={<BookOpen className="text-teal-600" size={32} />}
                  title="Course Management"
                  description="Comprehensive dashboard for lecturers to schedule classes and for students to access recordings and resources."
               />
            </div>
         </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
           <div className="flex items-center space-x-3">
             <div className="bg-blue-50 p-2 rounded-full">
                <GraduationCap size={20} className="text-blue-900" />
             </div>
             <div>
               <p className="font-semibold text-gray-900">Captain Elechi Amadi Polytechnic</p>
               <p className="text-xs text-gray-500">Computer Science Department</p>
             </div>
           </div>
           <div className="text-sm text-gray-500">
             &copy; {new Date().getFullYear()} PolyVirtual. All rights reserved.
           </div>
        </div>
      </footer>
    </div>
  );
};

const FeatureCard = ({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) => (
  <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 hover:shadow-lg transition-all hover:-translate-y-1 duration-300">
    <div className="mb-5 bg-gray-50 w-16 h-16 rounded-2xl flex items-center justify-center">{icon}</div>
    <h3 className="text-xl font-bold text-gray-900 mb-3">{title}</h3>
    <p className="text-gray-600 leading-relaxed">{description}</p>
  </div>
);

export default Welcome;
