import { GoogleGenAI } from "@google/genai";

// Initialize Gemini Client
// In a real production app, ensure this key is proxy-wrapped or strictly strictly controlled.
// For this frontend demo, we assume process.env.API_KEY is injected safely.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const askTeachingAssistant = async (question: string, context: string): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash';
    
    const systemPrompt = `You are an expert Computer Science Teaching Assistant at Captain Elechi Amadi Polytechnic. 
    You are helpful, concise, and academic in tone. 
    The current class context is: ${context}.
    Answer the student's question related to Computer Science or the current topic.
    If the question is irrelevant, politely steer them back to the topic.
    Keep answers under 100 words for chat readability.`;

    const response = await ai.models.generateContent({
      model: model,
      contents: question,
      config: {
        systemInstruction: systemPrompt,
      }
    });

    return response.text || "I apologize, I couldn't process that question right now.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "The AI Assistant is currently offline. Please ask the lecturer directly.";
  }
};

export const summarizeClassChat = async (chatHistory: string, courseContext: string): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash';
    const systemPrompt = `You are an expert academic assistant.
    Summarize the following live class chat discussion for the course: ${courseContext}.
    Identify the key questions asked by students and the main concepts discussed.
    Format the output as a concise bulleted list.
    Keep the summary under 150 words.`;

    const response = await ai.models.generateContent({
      model: model,
      contents: chatHistory,
      config: {
        systemInstruction: systemPrompt,
      }
    });

    return response.text || "Could not generate summary.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Summary generation is currently unavailable.";
  }
};