export enum UserRole {
  STUDENT = 'Student',
  LECTURER = 'Lecturer',
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
}

export interface Message {
  id: string;
  senderId: string;
  senderName: string;
  content: string;
  timestamp: Date;
  isAi?: boolean;
}

export interface ClassSession {
  id: string;
  title: string;
  courseCode: string;
  instructor: string;
  startTime: string;
  isActive: boolean;
  topic: string;
  description?: string;
  credits?: number;
}
